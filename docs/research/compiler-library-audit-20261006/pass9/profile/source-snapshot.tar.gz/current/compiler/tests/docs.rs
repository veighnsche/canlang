//! D04b extractor tests: the Rust reference extractor builds frozen
//! ReferenceModel v1 from analysis (extraction only — rendering is D05a's,
//! CLI is D05b's). Fixtures pin the model shape against
//! `packages/contracts/src/reference.ts`: declaration set, types and
//! nullability vs creation requiredness, defaults, resolved constraints,
//! user operations, labeled authored examples, canonical links, explicit
//! unknown availability and determinism. No execution status, inferred
//! authorization or invented results anywhere.

use canlang_compiler::analysis::catalog::{Catalog, CatalogRequest, load_catalog};
use canlang_compiler::analysis::{CheckedProgram, check_program};
use canlang_compiler::diagnostic::Diagnostic;
use canlang_compiler::docs::{
    REFERENCE_MODEL_VERSION, ReferenceAvailability, ReferenceDescriptionValue, ReferenceModel,
    extract_reference, portable_source_id,
};
use canlang_compiler::json::{self, Json};
use canlang_compiler::source::{SourceDb, SourceId, Span};
use std::path::Path;

// --- Fixtures ---------------------------------------------------------------

/// Rich shop source: model + contract, a full field/description matrix, user
/// scenarios plus one trusted handler (excluded), and a fixture recipe.
/// Field order follows the parser: type, default/server, modifiers, desc.
const SHOP_SRC: &str = concat!(
    "app Shop\n",
    "Given\n",
    " # Gadgets for sale. @{nl=\"Gadgets te koop.\"}\n",
    " Gadget { title:text trim max=200 desc=\"Display title.\"@{nl=\"Titel.\", fr=null},",
    " stock:int=0 min=0 max=100, state:enum(open,done)=open, note:text?,",
    " owner:user server=actor, alias:text desc=\"\" }\n",
    " policy Gadget read=members\n",
    " contract Spec { summary:text, count:int=1 }\n",
    " fixture g0=Gadget {title=\"Sprocket\", alias=\"sp\"}\n",
    " event Pinged { g:Gadget }\n",
    "When\n",
    " # Restock a gadget. @{nl=\"Vul een gadget aan.\"}\n",
    " scenario restock(g:Gadget, amount:int=1, note:text? desc=\"Why restocked.\") by=members -> int\n",
    "  do\n",
    "   return 1\n",
    " scenario ping() by=members\n",
    "  do\n",
    "   let x = 1\n",
    " scenario onping on=Pinged\n",
    "  do\n",
    "   let x = 1\n",
    "Then\n",
);

/// Table-form `examples` attach to operations (unlabeled in source): they
/// must not leak into declaration examples. (Source mirrors the known-clean
/// header shape from `b4_examples.rs`.)
const TABLE_SRC: &str = concat!(
    "app Probe\n",
    "Given\n",
    " Task { title:text, state:enum(open,done)=open }\n",
    " policy Task read=members\n",
    " fixture one=Task { title=\"a\", state=open }\n",
    "When\n",
    " scenario close(task:Task,state:Task.state) by=members\n",
    "  require task.state==open\n",
    "  do set task {state=done}\n",
    "  examples seed=[one] task=one state=done\n",
    "   as,task.state -> task.state\n",
    "   members,open -> done\n",
    "   members,done -> error(rule_failed)\n",
    "Then\n",
);

/// Declaration `#= message` references resolve to recorded message wording.
const MESSAGE_REF_SRC: &str = concat!(
    "app Shop\n",
    "Given\n",
    " message blurb = \"Shared wording.\"@{nl=\"Gedeelde tekst.\"}\n",
    " #= blurb\n",
    " Gadget { title:text }\n",
    " policy Gadget read=members\n",
    "When\n",
    "Then\n",
);

/// Required-array `!` spelling reconstructs the declared field-type spelling.
const ARRAY_SRC: &str = concat!(
    "app Shop\n",
    "Given\n",
    " Gadget { tags:text[]! }\n",
    " policy Gadget read=members\n",
    "When\n",
    "Then\n",
);

/// Check one inline source without a catalog (fixtures use no builtins),
/// asserting clean diagnostics and returning db + program for extraction.
fn check_clean(path: &str, src: &str) -> (SourceDb, SourceId, CheckedProgram) {
    let mut db = SourceDb::new();
    let id = db.add(path.to_string(), src.to_string());
    let (program, diags) = check_program(&db, &[id], None);
    assert!(diags.is_empty(), "fixture must check clean: {diags:?}");
    (db, id, program)
}

fn extract(path: &str, src: &str) -> (String, ReferenceModel) {
    let (db, id, program) = check_clean(path, src);
    let model = extract_reference(&db, &[id], &program);
    (model.to_json_string(), model)
}

/// Minimal test-only catalog pinning `catalog_version` (temp-dir pattern
/// from `b4_examples.rs`).
fn fixture_catalog() -> (TempfileGuard, Catalog) {
    let json = r#"{
  "language_version": "1.0",
  "catalog_version": "2.5.0-test",
  "entries": [
    {"id": "count", "js": "count", "owner": "test", "kind": "builtin", "signature": "count(domain:C<T>)->int", "effects": "pure", "availability": "implemented"}
  ]
}"#;
    let dir = std::env::temp_dir().join(format!(
        "can-docs-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .expect("clock")
            .as_nanos()
    ));
    std::fs::create_dir_all(&dir).unwrap();
    let path = dir.join("catalog.json");
    std::fs::write(&path, json).unwrap();
    let mut db = SourceDb::new();
    let id = db.add("dummy.can".to_string(), String::new());
    let request = CatalogRequest {
        flag: Some(&path),
        env: None,
        cwd: Path::new("."),
        primary: Span::new(id, 0, 0),
    };
    let (catalog, diags) = load_catalog(&request);
    assert!(diags.is_empty(), "fixture catalog loads clean: {diags:?}");
    (TempfileGuard { dir }, catalog.expect("fixture catalog"))
}

/// Removes the temp catalog dir on drop (test-only cleanup).
struct TempfileGuard {
    dir: std::path::PathBuf,
}

impl Drop for TempfileGuard {
    fn drop(&mut self) {
        let _ = std::fs::remove_dir_all(&self.dir);
    }
}

/// Byte span of the first appearance of `needle` in `src`.
fn span_of(src: &str, needle: &str) -> (u32, u32) {
    let at = src
        .find(needle)
        .unwrap_or_else(|| panic!("needle {needle:?} missing"));
    (at as u32, (at + needle.len()) as u32)
}

// --- Declaration set ---------------------------------------------------------

/// (D04b) Owners, models/contracts and fields extract with canonical links:
/// one owner, declarations sorted by name, events excluded, project-relative
/// source ids plus offsets on every location.
#[test]
fn extracts_owners_declarations_and_fields() {
    let (_json, model) = extract("shop.can", SHOP_SRC);
    assert_eq!(model.version, REFERENCE_MODEL_VERSION);
    assert_eq!(model.owners.len(), 1);
    let owner = &model.owners[0];
    assert_eq!(owner.name, "Shop");
    let names: Vec<(&str, &str)> = owner
        .declarations
        .iter()
        .map(|d| {
            (
                d.name.as_str(),
                match d.kind {
                    canlang_compiler::docs::ReferenceDeclarationKind::Model => "model",
                    canlang_compiler::docs::ReferenceDeclarationKind::Contract => "contract",
                },
            )
        })
        .collect();
    // Sorted by name; the `Pinged` event is not a model/contract.
    assert_eq!(names, vec![("Gadget", "model"), ("Spec", "contract")]);
    for declaration in &owner.declarations {
        assert_eq!(declaration.owner, "Shop");
        assert_eq!(declaration.location.source_id, "shop.can");
        let slice =
            &SHOP_SRC[declaration.location.start as usize..declaration.location.end as usize];
        assert!(
            slice.contains(&declaration.name),
            "location covers the declaration: {slice:?}"
        );
    }
    let gadget = &owner.declarations[0];
    let fields: Vec<&str> = gadget.fields.iter().map(|f| f.name.as_str()).collect();
    assert_eq!(
        fields,
        vec!["title", "stock", "state", "note", "owner", "alias"]
    );
    let spec = &owner.declarations[1];
    let spec_fields: Vec<&str> = spec.fields.iter().map(|f| f.name.as_str()).collect();
    assert_eq!(spec_fields, vec!["summary", "count"]);
}

/// (D04b) Field matrix: declared spellings, nullability, creation
/// requiredness distinct from nullability, defaults and resolved constraints
/// in written order.
#[test]
fn field_type_nullability_requiredness_defaults_constraints() {
    let (_json, model) = extract("shop.can", SHOP_SRC);
    let gadget = &model.owners[0].declarations[0];
    let field = |name: &str| {
        gadget
            .fields
            .iter()
            .find(|f| f.name == name)
            .unwrap_or_else(|| panic!("field {name} missing"))
    };
    // Plain required text: non-null, creation-required, no default.
    let title = field("title");
    assert_eq!(title.ty, "text");
    assert!(!title.nullable);
    assert!(title.creation_required);
    assert_eq!(title.default, None);
    assert_eq!(
        title
            .constraints
            .iter()
            .map(|c| (c.kind.as_str(), c.detail.as_str()))
            .collect::<Vec<_>>(),
        vec![("trim", "trim"), ("max", "200")]
    );
    // Defaulted int with bounds: not creation-required despite non-null.
    let stock = field("stock");
    assert_eq!(stock.ty, "int");
    assert!(!stock.nullable);
    assert!(!stock.creation_required);
    assert_eq!(stock.default.as_deref(), Some("0"));
    assert_eq!(
        stock
            .constraints
            .iter()
            .map(|c| (c.kind.as_str(), c.detail.as_str()))
            .collect::<Vec<_>>(),
        vec![("min", "0"), ("max", "100")]
    );
    // Enum with default: declared spelling kept, not required.
    let state = field("state");
    assert_eq!(state.ty, "enum(open,done)");
    assert!(!state.nullable);
    assert!(!state.creation_required);
    assert_eq!(state.default.as_deref(), Some("open"));
    assert!(state.constraints.is_empty());
    // Nullable without default: fills null when omitted, not required.
    let note = field("note");
    assert_eq!(note.ty, "text?");
    assert!(note.nullable);
    assert!(!note.creation_required);
    assert_eq!(note.default, None);
    // Server-owned: never caller-provided, never creation-required.
    let owner = field("owner");
    assert_eq!(owner.ty, "user");
    assert!(!owner.nullable);
    assert!(!owner.creation_required);
    // Contract field with default.
    let spec = &model.owners[0].declarations[1];
    let count = spec.fields.iter().find(|f| f.name == "count").unwrap();
    assert_eq!(count.ty, "int");
    assert!(!count.creation_required);
    assert_eq!(count.default.as_deref(), Some("1"));
}

// --- Operations ---------------------------------------------------------------

/// (D04b) User scenarios extract with inputs in signature order and declared
/// results; trusted handlers are not user operations. Operation JSON carries
/// the callable surface only — no `by=` gate, role or permission material.
#[test]
fn extracts_user_operations_without_authorization() {
    let (json, model) = extract("shop.can", SHOP_SRC);
    let operations = &model.owners[0].operations;
    let ids: Vec<&str> = operations.iter().map(|o| o.id.as_str()).collect();
    assert_eq!(ids, vec!["Shop.ping", "Shop.restock"]);
    assert!(
        !ids.iter().any(|id| id.contains("onping")),
        "trusted handler excluded: {ids:?}"
    );
    let restock = operations.iter().find(|o| o.id == "Shop.restock").unwrap();
    let inputs: Vec<(&str, &str, bool, bool, Option<&str>)> = restock
        .inputs
        .iter()
        .map(|i| {
            (
                i.name.as_str(),
                i.ty.as_str(),
                i.nullable,
                i.creation_required,
                i.default.as_deref(),
            )
        })
        .collect();
    assert_eq!(
        inputs,
        vec![
            ("g", "Gadget", false, true, None),
            ("amount", "int", false, false, Some("1")),
            ("note", "text?", true, false, None),
        ]
    );
    for input in &restock.inputs {
        assert!(
            input.constraints.is_empty(),
            "parameters carry no modifiers"
        );
    }
    assert_eq!(restock.result.ty, "int");
    assert!(!restock.result.nullable);
    assert_eq!(restock.result.description, None);
    assert_eq!(restock.location.source_id, "shop.can");
    // Void scenario: no inputs, `void` result, never nullable.
    let ping = operations.iter().find(|o| o.id == "Shop.ping").unwrap();
    assert!(ping.inputs.is_empty());
    assert_eq!(ping.result.ty, "void");
    assert!(!ping.result.nullable);
    // Callable surface only: the `by=members` gate must not leak.
    assert!(
        !json.contains("members"),
        "no caller gate in reference JSON"
    );
    let value = json::parse(&json).expect("reference JSON parses");
    let owners = value.get("owners").and_then(Json::as_arr).unwrap();
    let ops = owners[0].get("operations").and_then(Json::as_arr).unwrap();
    for op in ops {
        let Json::Obj(members) = op else {
            panic!("operation must be an object");
        };
        let keys: Vec<&str> = members.iter().map(|(k, _)| k.as_str()).collect();
        // R4 rationale: `examples` joins the callable surface (owned table
        // rows); still no gate, role or permission material.
        assert!(
            keys.iter().all(|k| matches!(
                *k,
                "id" | "description" | "inputs" | "result" | "examples" | "location"
            )),
            "operation keys are the callable surface only: {keys:?}"
        );
    }
}

// --- Descriptions ---------------------------------------------------------------

/// (D04b) Field/parameter descriptions come from the frozen checked seam:
/// source text, ordered variants with `null` kept distinct from text, owning
/// source language and authored-value locations. Undescribed slots stay
/// absent; authored-empty text (`desc=""`) stays present-but-empty.
#[test]
fn field_and_param_descriptions_use_checked_seam() {
    let (_json, model) = extract("shop.can", SHOP_SRC);
    let gadget = &model.owners[0].declarations[0];
    let title = gadget.fields.iter().find(|f| f.name == "title").unwrap();
    let description = title.description.as_ref().expect("title described");
    assert_eq!(description.source, "Display title.");
    assert_eq!(description.source_lang, "en");
    assert_eq!(
        description
            .variants
            .iter()
            .map(|v| (v.tag.as_str(), v.text.as_deref()))
            .collect::<Vec<_>>(),
        vec![("nl", Some("Titel.")), ("fr", None)]
    );
    assert_eq!(description.location.source_id, "shop.can");
    let slice = &SHOP_SRC[description.location.start as usize..description.location.end as usize];
    assert!(
        slice.contains("desc=\"Display title.\""),
        "value location covers desc=: {slice:?}"
    );
    // Undescribed sibling: absent, never empty.
    let stock = gadget.fields.iter().find(|f| f.name == "stock").unwrap();
    assert_eq!(stock.description, None);
    // Authored-empty text is present-but-empty, distinct from absence.
    let alias = gadget.fields.iter().find(|f| f.name == "alias").unwrap();
    let empty = alias.description.as_ref().expect("empty desc present");
    assert_eq!(empty.source, "");
    assert!(empty.variants.is_empty());
    // Parameter description from the same seam.
    let restock = model.owners[0]
        .operations
        .iter()
        .find(|o| o.id == "Shop.restock")
        .unwrap();
    let note = restock.inputs.iter().find(|i| i.name == "note").unwrap();
    assert_eq!(
        note.description.as_ref().map(|d| d.source.as_str()),
        Some("Why restocked.")
    );
    let amount = restock.inputs.iter().find(|i| i.name == "amount").unwrap();
    assert_eq!(amount.description, None);
}

/// (D04b) Attached `#` sets describe owning model/operation declarations;
/// undescribed declarations stay absent.
#[test]
fn declaration_descriptions_attach_from_hash_sets() {
    let (_json, model) = extract("shop.can", SHOP_SRC);
    let owner = &model.owners[0];
    let gadget = owner
        .declarations
        .iter()
        .find(|d| d.name == "Gadget")
        .unwrap();
    let description = gadget.description.as_ref().expect("model described");
    assert_eq!(description.source, "Gadgets for sale.");
    assert_eq!(description.source_lang, "en");
    assert_eq!(
        description
            .variants
            .iter()
            .map(|v| (v.tag.as_str(), v.text.as_deref()))
            .collect::<Vec<_>>(),
        vec![("nl", Some("Gadgets te koop."))]
    );
    let restock = owner
        .operations
        .iter()
        .find(|o| o.id == "Shop.restock")
        .unwrap();
    assert_eq!(
        restock.description.as_ref().map(|d| d.source.as_str()),
        Some("Restock a gadget.")
    );
    let spec = owner
        .declarations
        .iter()
        .find(|d| d.name == "Spec")
        .unwrap();
    assert_eq!(spec.description, None);
    let ping = owner
        .operations
        .iter()
        .find(|o| o.id == "Shop.ping")
        .unwrap();
    assert_eq!(ping.description, None);
}

/// (D04b) Declaration `#= message` references resolve to recorded message
/// wording under the message's owning source language.
#[test]
fn message_reference_descriptions_resolve() {
    let (_json, model) = extract("shop.can", MESSAGE_REF_SRC);
    let gadget = &model.owners[0].declarations[0];
    assert_eq!(gadget.name, "Gadget");
    let description = gadget.description.as_ref().expect("ref described");
    assert_eq!(description.source, "Shared wording.");
    assert_eq!(description.source_lang, "en");
    assert_eq!(
        description
            .variants
            .iter()
            .map(|v| (v.tag.as_str(), v.text.as_deref()))
            .collect::<Vec<_>>(),
        vec![("nl", Some("Gedeelde tekst."))]
    );
    let (start, _) = span_of(MESSAGE_REF_SRC, "#= blurb");
    assert_eq!(description.location.source_id, "shop.can");
    assert!(
        description.location.start <= start && start < description.location.end,
        "location covers the `#=` leaf"
    );
}

/// (D04b) Required-array `!` reconstructs the declared field-type spelling.
#[test]
fn required_array_spelling_is_preserved() {
    let (_json, model) = extract("shop.can", ARRAY_SRC);
    let gadget = &model.owners[0].declarations[0];
    let tags = gadget.fields.iter().find(|f| f.name == "tags").unwrap();
    assert_eq!(tags.ty, "text[]!");
    assert!(!tags.nullable);
    assert!(tags.creation_required);
}

// --- Examples -------------------------------------------------------------------

/// (D04b) Fixtures targeting a declaration become its labeled authored
/// examples (source label, recipe slice, no expected result, no execution
/// status). Operation-attached `examples` tables belong to their operation
/// (R4 row examples), so tables never leak into declaration examples.
#[test]
fn fixtures_become_labeled_declaration_examples() {
    let (json, model) = extract("shop.can", SHOP_SRC);
    let owner = &model.owners[0];
    let gadget = owner
        .declarations
        .iter()
        .find(|d| d.name == "Gadget")
        .unwrap();
    assert_eq!(gadget.examples.len(), 1);
    let example = &gadget.examples[0];
    assert_eq!(example.label, "g0");
    assert!(
        example.source.contains("fixture g0=Gadget"),
        "recipe slice: {:?}",
        example.source
    );
    assert_eq!(example.expected, None);
    let spec = owner
        .declarations
        .iter()
        .find(|d| d.name == "Spec")
        .unwrap();
    assert!(spec.examples.is_empty());
    // No execution status invented anywhere in the payload.
    for forbidden in ["passed", "failed", "executed", "execution", "error("] {
        assert!(
            !json.contains(forbidden),
            "no {forbidden:?} in reference JSON"
        );
    }
    // Tables attach to operations, not declarations: only the fixture lands.
    let (_table_json, table_model) = extract("probe.can", TABLE_SRC);
    let task = &table_model.owners[0].declarations[0];
    assert_eq!(task.name, "Task");
    let labels: Vec<&str> = task.examples.iter().map(|e| e.label.as_str()).collect();
    assert_eq!(labels, vec!["one"]);
}

// --- Availability, versions, determinism ------------------------------------------

/// (D04b) Availability is explicitly unknown without a verified fact, and the
/// catalog version is `null` when no catalog contributed. Even with a
/// catalog, passing analysis never flips availability to available.
#[test]
fn availability_is_unknown_and_catalog_version_nullable() {
    let (json, model) = extract("shop.can", SHOP_SRC);
    assert_eq!(model.availability, ReferenceAvailability::Unknown);
    assert_eq!(model.catalog_version, None);
    assert_eq!(model.language_version, "1.0");
    assert_eq!(model.app_default_locale, "en");
    let value = json::parse(&json).expect("reference JSON parses");
    assert_eq!(
        value.get("catalogVersion"),
        Some(&Json::Null),
        "null catalog version without a catalog"
    );
    assert_eq!(
        value.get("availability"),
        Some(&Json::Obj(vec![(
            "status".to_string(),
            Json::Str("unknown".to_string())
        )]))
    );
    // With a catalog: version passes through, availability stays unknown.
    let (_guard, catalog) = fixture_catalog();
    let mut db = SourceDb::new();
    let id = db.add("shop.can".to_string(), SHOP_SRC.to_string());
    let (program, diags): (CheckedProgram, Vec<Diagnostic>) =
        check_program(&db, &[id], Some(&catalog));
    assert!(diags.is_empty(), "catalog run must check clean: {diags:?}");
    let model = extract_reference(&db, &[id], &program);
    assert_eq!(model.catalog_version.as_deref(), Some("2.5.0-test"));
    assert_eq!(model.availability, ReferenceAvailability::Unknown);
}

/// (D04b) The `available` shape conforms to the frozen contract when a
/// verified fact constructs it (renderer agreement; the extractor itself
/// never invents one).
#[test]
fn available_shape_conforms_when_constructed() {
    let available = ReferenceAvailability::Available {
        owner: "TeamTasks".to_string(),
        catalog: "catalog-7".to_string(),
    };
    let value = available.to_json();
    assert_eq!(
        value,
        Json::Obj(vec![
            ("status".to_string(), Json::Str("available".to_string())),
            ("owner".to_string(), Json::Str("TeamTasks".to_string())),
            ("catalog".to_string(), Json::Str("catalog-7".to_string())),
        ])
    );
}

/// (D04b) Output is deterministic: repeated extraction is identical, owners
/// sort by name, and file order never affects the payload or revision.
#[test]
fn output_is_deterministic() {
    let (json_a, model_a) = extract("shop.can", SHOP_SRC);
    let (json_b, model_b) = extract("shop.can", SHOP_SRC);
    assert_eq!(model_a, model_b);
    assert_eq!(json_a, json_b);
    assert_eq!(model_a.version, 1);
    // Two files added out of order: owners sort, revision is order-free.
    let mut db = SourceDb::new();
    let zed = db.add(
        "zed.can".to_string(),
        "app Zed\nGiven\n Widget { title:text }\n policy Widget read=members\nWhen\nThen\n"
            .to_string(),
    );
    let amy = db.add(
        "amy.can".to_string(),
        "app Amy\nGiven\n Gadget { title:text }\n policy Gadget read=members\nWhen\nThen\n"
            .to_string(),
    );
    let (program, diags) = check_program(&db, &[zed, amy], None);
    assert!(diags.is_empty(), "two-file run checks clean: {diags:?}");
    let first = extract_reference(&db, &[zed, amy], &program);
    let second = extract_reference(&db, &[amy, zed], &program);
    assert_eq!(first, second);
    assert_eq!(first.to_json_string(), second.to_json_string());
    let names: Vec<&str> = first.owners.iter().map(|o| o.name.as_str()).collect();
    assert_eq!(names, vec!["Amy", "Zed"]);
}

// --- Contract conformance -------------------------------------------------------

/// (D04b) The JSON payload matches `reference.ts` exactly: top-level keys in
/// contract order, `version` 1, camelCase throughout, `None` optionals
/// omitted (never `null` except `catalogVersion`/variant `text`).
#[test]
fn v1_json_conforms_to_reference_ts() {
    let (json, _model) = extract("shop.can", SHOP_SRC);
    let value = json::parse(&json).expect("reference JSON parses");
    let Json::Obj(top) = &value else {
        panic!("model must be an object");
    };
    let keys: Vec<&str> = top.iter().map(|(k, _)| k.as_str()).collect();
    assert_eq!(
        keys,
        vec![
            "version",
            "sourceRevision",
            "catalogVersion",
            "languageVersion",
            "appDefaultLocale",
            "owners",
            "availability"
        ]
    );
    assert_eq!(value.get("version"), Some(&Json::Num("1".to_string())));
    assert_eq!(
        value.get("languageVersion").and_then(Json::as_str),
        Some("1.0")
    );
    assert_eq!(
        value.get("appDefaultLocale").and_then(Json::as_str),
        Some("en")
    );
    let revision = value.get("sourceRevision").and_then(Json::as_str).unwrap();
    assert_eq!(revision.len(), 64, "hex SHA-256 revision");
    assert!(revision.bytes().all(|b| b.is_ascii_hexdigit()));
    // Declaration/field/operation/example key shapes + optional omission.
    let owners = value.get("owners").and_then(Json::as_arr).unwrap();
    let gadget = owners[0]
        .get("declarations")
        .and_then(Json::as_arr)
        .unwrap()[0]
        .clone();
    let Json::Obj(decl) = &gadget else {
        panic!("declaration must be an object");
    };
    let decl_keys: Vec<&str> = decl.iter().map(|(k, _)| k.as_str()).collect();
    assert_eq!(
        decl_keys,
        vec![
            "owner",
            "name",
            "kind",
            "description",
            "fields",
            "examples",
            "location"
        ]
    );
    assert_eq!(gadget.get("kind").and_then(Json::as_str), Some("model"));
    let fields = gadget.get("fields").and_then(Json::as_arr).unwrap();
    let title = &fields[0];
    assert!(title.get("default").is_none(), "no default: key omitted");
    assert!(title.get("description").is_some(), "described: key present");
    let stock = &fields[1];
    assert_eq!(stock.get("default").and_then(Json::as_str), Some("0"));
    assert!(
        stock.get("description").is_none(),
        "undescribed: key omitted"
    );
    assert_eq!(stock.get("creationRequired"), Some(&Json::Bool(false)));
    let description = title.get("description").unwrap();
    let Json::Obj(desc) = description else {
        panic!("description must be an object");
    };
    let desc_keys: Vec<&str> = desc.iter().map(|(k, _)| k.as_str()).collect();
    assert_eq!(
        desc_keys,
        vec!["source", "sourceLang", "variants", "location"]
    );
    let variants = description.get("variants").and_then(Json::as_arr).unwrap();
    assert_eq!(variants.len(), 2);
    assert_eq!(variants[1].get("text"), Some(&Json::Null));
    let examples = gadget.get("examples").and_then(Json::as_arr).unwrap();
    assert_eq!(examples.len(), 1);
    assert!(
        examples[0].get("expected").is_none(),
        "no expected: omitted"
    );
    assert!(examples[0].get("label").and_then(Json::as_str).is_some());
    let location = gadget.get("location").unwrap();
    let Json::Obj(loc) = location else {
        panic!("location must be an object");
    };
    let loc_keys: Vec<&str> = loc.iter().map(|(k, _)| k.as_str()).collect();
    assert_eq!(loc_keys, vec!["sourceId", "start", "end"]);
    assert_eq!(
        location.get("sourceId").and_then(Json::as_str),
        Some("shop.can")
    );
}

// --- Portability (R-D07-03) ----------------------------------------------------

/// (R3) Relative and absolute spellings of the same input yield identical
/// portable output bytes: the absolute path under the project root (the
/// process working directory) normalizes to the same project-relative
/// sourceId and the same sourceRevision, leaking no checkout prefix.
#[test]
fn relative_vs_absolute_spellings_are_identical() {
    let (relative_json, relative_model) = extract("shop.can", SHOP_SRC);
    let cwd = std::env::current_dir().expect("cwd");
    let absolute = cwd.join("shop.can").to_string_lossy().into_owned();
    assert!(
        std::path::Path::new(&absolute).is_absolute(),
        "absolute spelling: {absolute:?}"
    );
    let (absolute_json, absolute_model) = extract(&absolute, SHOP_SRC);
    assert_eq!(absolute_json, relative_json, "same output bytes");
    assert_eq!(absolute_model, relative_model);
    assert_eq!(
        absolute_model.source_revision, relative_model.source_revision,
        "same revision"
    );
    for owner in &absolute_model.owners {
        for declaration in &owner.declarations {
            assert_eq!(declaration.location.source_id, "shop.can");
        }
        for operation in &owner.operations {
            assert_eq!(operation.location.source_id, "shop.can");
        }
    }
    assert!(
        !absolute_json.contains(&absolute),
        "no absolute checkout path leaks into portable output"
    );
}

/// (R3) Moved-checkout equivalence: the same project content at a different
/// absolute prefix yields identical portable identities. Two scratch
/// checkouts with the same relative layout normalize — each against its
/// own checkout root, as `can docs` would when run inside that checkout —
/// to the same project-relative sourceId, and extraction over those
/// identities is byte-identical with the same sourceRevision.
#[test]
fn moved_checkout_equivalence() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let base = std::env::temp_dir().join(format!("can-docs-r3-{}-{nanos}", std::process::id()));
    let dir_a = base.join("checkout-a");
    let dir_b = base.join("checkout-b");
    std::fs::create_dir_all(&dir_a).unwrap();
    std::fs::create_dir_all(&dir_b).unwrap();
    let _guard = TempfileGuard { dir: base };
    std::fs::write(dir_a.join("shop.can"), SHOP_SRC).unwrap();
    std::fs::write(dir_b.join("shop.can"), SHOP_SRC).unwrap();
    let abs_a = dir_a.join("shop.can");
    let abs_b = dir_b.join("shop.can");
    assert_ne!(abs_a, abs_b, "different absolute prefixes");
    let rel_a = portable_source_id(&abs_a.to_string_lossy(), &dir_a);
    let rel_b = portable_source_id(&abs_b.to_string_lossy(), &dir_b);
    assert_eq!(rel_a, "shop.can", "checkout A relativizes");
    assert_eq!(rel_b, "shop.can", "checkout B relativizes");
    let (json_a, model_a) = extract(&rel_a, SHOP_SRC);
    let (json_b, model_b) = extract(&rel_b, SHOP_SRC);
    assert_eq!(json_a, json_b, "same output bytes across checkouts");
    assert_eq!(model_a, model_b);
    assert_eq!(model_a.source_revision, model_b.source_revision);
}

/// (R3) External inputs stay truthful: an absolute path outside the project
/// root is marked `external:...` (never silently relabeled as
/// project-relative) and the marking is stable across extractions.
#[test]
fn external_inputs_are_marked_and_stable() {
    // Unresolvable absolute outside any realistic checkout root: the
    // lexical fallback marks it external deterministically (no file needed).
    let outside = "/r3-external-probe-9f2c31/shop.can";
    assert!(std::path::Path::new(outside).is_absolute());
    let (json_a, model_a) = extract(outside, SHOP_SRC);
    let (json_b, model_b) = extract(outside, SHOP_SRC);
    assert_eq!(json_a, json_b, "stable bytes");
    assert_eq!(model_a, model_b);
    assert_eq!(model_a.source_revision, model_b.source_revision);
    let source_id = model_a.owners[0].declarations[0].location.source_id.clone();
    assert!(
        source_id.starts_with("external:"),
        "marked external: {source_id:?}"
    );
    assert!(
        source_id.contains("r3-external-probe-9f2c31"),
        "truthful absolute preserved: {source_id:?}"
    );
    for owner in &model_a.owners {
        for declaration in &owner.declarations {
            assert_eq!(declaration.location.source_id, source_id);
        }
        for operation in &owner.operations {
            assert_eq!(operation.location.source_id, source_id);
        }
    }
    // A real temp file outside the checkout agrees through the canonical path.
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let dir = std::env::temp_dir().join(format!("can-docs-r3-ext-{}-{nanos}", std::process::id()));
    std::fs::create_dir_all(&dir).unwrap();
    let _guard = TempfileGuard { dir: dir.clone() };
    let file = dir.join("shop.can");
    std::fs::write(&file, SHOP_SRC).unwrap();
    let real_abs = file.to_string_lossy().into_owned();
    let (_real_json, real_model) = extract(&real_abs, SHOP_SRC);
    let real_id = &real_model.owners[0].declarations[0].location.source_id;
    assert!(
        real_id.starts_with("external:"),
        "real outside file marked external: {real_id:?}"
    );
}

// --- Operation row examples (R-D07-04) -----------------------------------------

/// (R4) Table-form `examples` attached to a user operation become its owned
/// row examples: one positional entry per data row (header skipped), with
/// authored input cells plus the authored expectation — including
/// `error(code)` spellings. No execution status is invented, and the
/// owning declaration keeps only its fixture (op rows are never absorbed).
#[test]
fn operation_tables_become_labeled_row_examples() {
    let (json, model) = extract("probe.can", TABLE_SRC);
    let close = model.owners[0]
        .operations
        .iter()
        .find(|o| o.id == "Probe.close")
        .expect("close operation extracted");
    let rows: Vec<(&str, &str, Option<&str>)> = close
        .examples
        .iter()
        .map(|e| (e.label.as_str(), e.source.as_str(), e.expected.as_deref()))
        .collect();
    assert_eq!(
        rows,
        vec![
            ("row-1", "members,open", Some("done")),
            ("row-2", "members,done", Some("error(rule_failed)")),
        ]
    );
    // The owning declaration keeps only its fixture: op rows stay out.
    let task = &model.owners[0].declarations[0];
    assert_eq!(task.name, "Task");
    let labels: Vec<&str> = task.examples.iter().map(|e| e.label.as_str()).collect();
    assert_eq!(labels, vec!["one"]);
    // Authored expectations travel; execution status never does. (`failed`
    // is only forbidden as a quoted status value: the authored
    // `error(rule_failed)` spelling legitimately contains it.)
    assert!(
        json.contains("error(rule_failed)"),
        "authored expectation kept"
    );
    for forbidden in ["passed", "\"failed\"", "executed", "execution"] {
        assert!(
            !json.contains(forbidden),
            "no {forbidden:?} in reference JSON"
        );
    }
    // JSON shape: `examples` on the op with label/source/expected keys.
    let value = json::parse(&json).expect("reference JSON parses");
    let owners = value.get("owners").and_then(Json::as_arr).unwrap();
    let ops = owners[0].get("operations").and_then(Json::as_arr).unwrap();
    assert_eq!(ops.len(), 1);
    let op_examples = ops[0].get("examples").and_then(Json::as_arr).unwrap();
    assert_eq!(op_examples.len(), 2);
    assert_eq!(
        op_examples[0].get("label").and_then(Json::as_str),
        Some("row-1")
    );
    assert_eq!(
        op_examples[0].get("source").and_then(Json::as_str),
        Some("members,open")
    );
    assert_eq!(
        op_examples[0].get("expected").and_then(Json::as_str),
        Some("done")
    );
    assert_eq!(
        op_examples[1].get("expected").and_then(Json::as_str),
        Some("error(rule_failed)")
    );
    // Table-less operations carry an empty array (SHOP_SRC restock/ping).
    let (_shop_json, shop) = extract("shop.can", SHOP_SRC);
    for op in &shop.owners[0].operations {
        assert!(op.examples.is_empty(), "no tables, no examples: {}", op.id);
    }
}

// --- App-default locale (P-A) ----------------------------------------------------

/// Composed Dutch-source app selecting the shop package, with NO `context`
/// default: the single-app case must resolve to the pinned `"en"`, proving
/// `source=` is never read as the default (R-D07-05 conflation fix).
const PA_APP_SRC: &str = "app Shop uses=[shop] source=\"nl\"\n";

/// English package selected by the composed app (package bodies take
/// indented Given/When/Then sections).
const PA_PKG_SRC: &str = concat!(
    "package shop source=\"en\"\n",
    " Given\n",
    "  # Gadget prose. @{nl=\"Gadgettekst.\"}\n",
    "  Gadget { title:text }\n",
    "  policy Gadget read=members\n",
    " When\n",
    " Then\n",
);

/// Check several inline sources together without a catalog (mixed-module
/// inputs), asserting clean diagnostics.
fn check_clean_multi(sources: &[(&str, &str)]) -> (SourceDb, Vec<SourceId>, CheckedProgram) {
    let mut db = SourceDb::new();
    let ids: Vec<SourceId> = sources
        .iter()
        .map(|(path, src)| db.add(path.to_string(), src.to_string()))
        .collect();
    let (program, diags) = check_program(&db, &ids, None);
    assert!(diags.is_empty(), "fixture must check clean: {diags:?}");
    (db, ids, program)
}

/// (R5) Source language is NOT the app default (R-D07-05 conflation
/// fix): the composed `Shop` app declares `source="nl"` but no `context` /
/// `locale default=`, so the single-app default is the pinned `"en"`
/// (DESIGN:887) in both input orders. R4 P-A expected `"nl"` here by
/// reading the app's source tag; that conflated authored wording
/// (DESIGN:850) with viewer selection. No checked default is declared
/// anywhere in this fixture, so both orders agree on the pinned default
/// for the right reason.
#[test]
fn app_default_locale_follows_the_single_app_module() {
    for (first, second) in [
        (("shop-app.can", PA_APP_SRC), ("shop-pkg.can", PA_PKG_SRC)),
        (("shop-pkg.can", PA_PKG_SRC), ("shop-app.can", PA_APP_SRC)),
    ] {
        let (db, ids, program) = check_clean_multi(&[first, second]);
        let model = extract_reference(&db, &ids, &program);
        assert_eq!(
            model.app_default_locale, "en",
            "absent checked default resolves to pinned en ({} first)",
            first.0
        );
        // Per-description owner language stays independent of the default.
        let gadget = model
            .owners
            .iter()
            .flat_map(|o| &o.declarations)
            .find(|d| d.name == "Gadget")
            .expect("gadget extracted");
        let description = gadget.description.as_ref().expect("gadget described");
        assert_eq!(description.source, "Gadget prose.");
        assert_eq!(description.source_lang, "en");
    }
}

/// Two packages with mixed `source=` tags (package-only fallback input).
/// Packages admit no `context` (the parser accepts it only after an app
/// header), so no checked default is publishable here: both orders must
/// resolve to the pinned `"en"` regardless of the `source=` tags.
const FALLBACK_PKG_A_SRC: &str = concat!(
    "package Alpha source=\"nl\"\n",
    " Given\n",
    "  Gadget { title:text }\n",
    "  policy Gadget read=members\n",
    " When\n",
    " Then\n",
);

/// Second package with the other tag.
const FALLBACK_PKG_B_SRC: &str = concat!(
    "package Beta source=\"en\"\n",
    " Given\n",
    "  Gadget { title:text }\n",
    "  policy Gadget read=members\n",
    " When\n",
    " Then\n",
);

/// Implicit app with an explicit Dutch checked default (multi-app
/// fallback input): its default wins when it is the first module.
const FALLBACK_APP_A_SRC: &str = concat!(
    "app Alpha source=\"nl\"\n",
    "context\n",
    " locale default=\"nl\"\n",
    "Given\n",
    " Gadget { title:text }\n",
    " policy Gadget read=members\n",
    "When\n",
    "Then\n",
);

/// Second implicit app with NO `context` default: an unchanged default
/// must be omitted (DESIGN:887), so Beta-first resolves to the pinned
/// `"en"` — via absence, not via its `source="en"` tag.
const FALLBACK_APP_B_SRC: &str = concat!(
    "app Beta source=\"en\"\n",
    "Given\n",
    " Gadget { title:text }\n",
    " policy Gadget read=members\n",
    "When\n",
    "Then\n",
);

/// (R5) First-module fallback reads CHECKED defaults, never source tags.
/// Package-only inputs admit no publishable default (see above), so both
/// orders resolve to the pinned `"en"`. Multi-app inputs read the first
/// module's checked default: Alpha's explicit Dutch default wins when
/// Alpha is first, Beta's absent default pins `"en"` when Beta is first.
/// No invented policy beyond this documented order rule.
#[test]
fn app_default_locale_falls_back_to_first_module() {
    for (name, sources, wants) in [
        (
            "package-only",
            [
                ("alpha.can", FALLBACK_PKG_A_SRC),
                ("beta.can", FALLBACK_PKG_B_SRC),
            ],
            ["en", "en"],
        ),
        (
            "multi-app",
            [
                ("alpha.can", FALLBACK_APP_A_SRC),
                ("beta.can", FALLBACK_APP_B_SRC),
            ],
            ["nl", "en"],
        ),
    ] {
        for (first, second, want) in [
            (sources[0], sources[1], wants[0]),
            (sources[1], sources[0], wants[1]),
        ] {
            let (db, ids, program) = check_clean_multi(&[first, second]);
            let model = extract_reference(&db, &ids, &program);
            assert_eq!(
                model.app_default_locale, want,
                "{name} fallback: first module wins ({} first)",
                first.0
            );
        }
    }
}

// --- Checked locale default (R5) -------------------------------------------------

/// Composed English-source app with an explicit Dutch deployment default:
/// the checked default (`nl`) must win over the app's own `source="en"`.
const PA_APP_DEFAULT_SRC: &str = concat!(
    "app Shop uses=[shop] source=\"en\"\n",
    "context\n",
    " locale default=\"nl\"\n",
);

/// English package with one Dutch-variant description (default leg) and
/// one variant-less description (source leg) for the chain control.
const PA_CHAIN_PKG_SRC: &str = concat!(
    "package shop source=\"en\"\n",
    " Given\n",
    "  # Gadget prose. @{nl=\"Gadgettekst.\"}\n",
    "  Gadget { title:text }\n",
    "  # Widget prose.\n",
    "  Widget { title:text }\n",
    "  policy Gadget read=members\n",
    "  policy Widget read=members\n",
    " When\n",
    " Then\n",
);

/// Description wording of one extracted declaration by name.
fn described<'a>(model: &'a ReferenceModel, name: &str) -> &'a ReferenceDescriptionValue {
    model
        .owners
        .iter()
        .flat_map(|o| &o.declarations)
        .find(|d| d.name == name)
        .unwrap_or_else(|| panic!("{name} extracted"))
        .description
        .as_ref()
        .unwrap_or_else(|| panic!("{name} described"))
}

/// (R5) English source plus an explicit Dutch checked default resolves to
/// Dutch: the composed app's `locale default="nl"` wins over its own
/// `source="en"`, regardless of input order. The mirror of the
/// no-context correction above: source and default are independent facts.
#[test]
fn app_default_locale_prefers_the_checked_default_over_source() {
    for (first, second) in [
        (
            ("shop-app.can", PA_APP_DEFAULT_SRC),
            ("shop-pkg.can", PA_PKG_SRC),
        ),
        (
            ("shop-pkg.can", PA_PKG_SRC),
            ("shop-app.can", PA_APP_DEFAULT_SRC),
        ),
    ] {
        let (db, ids, program) = check_clean_multi(&[first, second]);
        let model = extract_reference(&db, &ids, &program);
        assert_eq!(
            model.app_default_locale, "nl",
            "explicit Dutch default wins over English source ({} first)",
            first.0
        );
        let gadget = described(&model, "Gadget");
        assert_eq!(gadget.source, "Gadget prose.");
        assert_eq!(gadget.source_lang, "en");
        let tags: Vec<&str> = gadget.variants.iter().map(|v| v.tag.as_str()).collect();
        assert_eq!(tags, vec!["nl"]);
    }
}

/// (R5) Requested → default → source chain payload (DESIGN:891): under an
/// explicit Dutch default over English sources, an unavailable requested
/// locale resolves per description — the Dutch variant where authored
/// (default leg), the English source where no Dutch variant exists
/// (source leg). Resolution itself is the existing TS `resolveVariant`
/// contract (requested → appDefault → source); this pins the Rust-side
/// payload triple (default + source + variants) in both input orders.
/// End-to-end rendering rides the `can docs --locale` probe.
#[test]
fn unavailable_requested_locale_falls_back_through_default_to_source() {
    for (first, second) in [
        (
            ("shop-app.can", PA_APP_DEFAULT_SRC),
            ("shop-pkg.can", PA_CHAIN_PKG_SRC),
        ),
        (
            ("shop-pkg.can", PA_CHAIN_PKG_SRC),
            ("shop-app.can", PA_APP_DEFAULT_SRC),
        ),
    ] {
        let (db, ids, program) = check_clean_multi(&[first, second]);
        let model = extract_reference(&db, &ids, &program);
        assert_eq!(
            model.app_default_locale, "nl",
            "chain runs under the explicit Dutch default ({} first)",
            first.0
        );
        // Default leg: Dutch variant over the English source.
        let gadget = described(&model, "Gadget");
        assert_eq!(gadget.source_lang, "en");
        let tags: Vec<&str> = gadget.variants.iter().map(|v| v.tag.as_str()).collect();
        assert_eq!(tags, vec!["nl"]);
        assert_eq!(gadget.variants[0].text.as_deref(), Some("Gadgettekst."));
        // Source leg: no variants, so the chain ends at the English source.
        let widget = described(&model, "Widget");
        assert_eq!(widget.source, "Widget prose.");
        assert_eq!(widget.source_lang, "en");
        assert!(widget.variants.is_empty());
    }
}

// --- Imported message wording (P-B) ----------------------------------------------

/// Imported bare `#= blurb`: package site imports blurb from shop and
/// describes its Gadget with it (checks clean; wording must resolve).
const IMPORTED_BARE_SRC: &str = concat!(
    "app Shop uses=[shop,site]\n",
    "package shop\n",
    " Given\n",
    "  export message blurb = \"Shared wording.\"@{nl=\"Gedeelde tekst.\"}\n",
    " When\n",
    " Then\n",
    "package site\n",
    " use shop {blurb}\n",
    " Given\n",
    "  #= blurb\n",
    "  Gadget { title:text }\n",
    "  policy Gadget read=members\n",
    " When\n",
    " Then\n",
);

/// Dotted `#= shop.blurb`: rejected by the checker (E2013), never rendered.
const DOTTED_REF_SRC: &str = concat!(
    "app Shop uses=[shop,site]\n",
    "package shop\n",
    " Given\n",
    "  export message blurb = \"Shared wording.\"@{nl=\"Gedeelde tekst.\"}\n",
    " When\n",
    " Then\n",
    "package site\n",
    " Given\n",
    "  #= shop.blurb\n",
    "  Widget { title:text }\n",
    "  policy Widget read=members\n",
    " When\n",
    " Then\n",
);

/// (R4 P-B) A bare `#= blurb` imported through the authoring module's `use`
/// scope resolves to the provider message's wording under its owning
/// source language.
#[test]
fn imported_bare_message_wording_resolves() {
    let (_json, model) = extract("site.can", IMPORTED_BARE_SRC);
    let site = model
        .owners
        .iter()
        .find(|o| o.name == "site")
        .expect("site owner extracted");
    let gadget = site
        .declarations
        .iter()
        .find(|d| d.name == "Gadget")
        .expect("gadget extracted");
    let description = gadget
        .description
        .as_ref()
        .expect("imported wording resolves");
    assert_eq!(description.source, "Shared wording.");
    assert_eq!(description.source_lang, "en");
    assert_eq!(
        description
            .variants
            .iter()
            .map(|v| (v.tag.as_str(), v.text.as_deref()))
            .collect::<Vec<_>>(),
        vec![("nl", Some("Gedeelde tekst."))]
    );
}

// --- Single root-aware path route (R-D07-03 remaining) ---------------------------

/// (R3b) Every spelling of one input normalizes against the same root:
/// `x`, `./x`, redundant components and the absolute spelling yield
/// byte-identical sourceIds plus an identical revision contribution.
#[test]
fn all_spellings_of_one_input_are_identical() {
    let cwd = std::env::current_dir().expect("cwd");
    let absolute = cwd.join("shop.can").to_string_lossy().into_owned();
    assert!(
        std::path::Path::new(&absolute).is_absolute(),
        "absolute spelling: {absolute:?}"
    );
    let spellings = [
        "shop.can".to_string(),
        "./shop.can".to_string(),
        "sub/../shop.can".to_string(),
        "./sub/../shop.can".to_string(),
        "sub/./../shop.can".to_string(),
        absolute.clone(),
    ];
    let (first_json, first_model) = extract(&spellings[0], SHOP_SRC);
    for spelling in &spellings[1..] {
        let (json, model) = extract(spelling, SHOP_SRC);
        assert_eq!(json, first_json, "same output bytes for {spelling:?}");
        assert_eq!(model, first_model, "same model for {spelling:?}");
        assert_eq!(
            model.source_revision, first_model.source_revision,
            "same revision for {spelling:?}"
        );
    }
    assert_eq!(
        first_model.owners[0].declarations[0].location.source_id,
        "shop.can"
    );
    for spelling in &spellings {
        assert_eq!(
            portable_source_id(spelling, &cwd),
            "shop.can",
            "same portable identity for {spelling:?}"
        );
    }
    assert!(
        !first_json.contains(&absolute),
        "no checkout prefix leaks into portable output"
    );
}

/// (R3b) Relative symlinks resolve through the same root: the link and its
/// target agree (relative and absolute spellings) on one identity.
#[test]
#[cfg(unix)]
fn relative_symlink_spellings_match_their_target() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let root =
        std::env::temp_dir().join(format!("can-docs-r3b-link-{}-{nanos}", std::process::id()));
    std::fs::create_dir_all(&root).unwrap();
    let _guard = TempfileGuard { dir: root.clone() };
    std::fs::write(root.join("real.can"), SHOP_SRC).unwrap();
    std::os::unix::fs::symlink("real.can", root.join("link.can")).unwrap();
    let via_link = portable_source_id("link.can", &root);
    let via_target = portable_source_id("real.can", &root);
    assert_eq!(via_link, via_target, "link agrees with its target");
    assert_eq!(via_target, "real.can");
    let abs_link = root.join("link.can").to_string_lossy().into_owned();
    assert_eq!(
        portable_source_id(&abs_link, &root),
        "real.can",
        "absolute link spelling agrees"
    );
}

/// (R3b) The same external file shares one identity and one external
/// classification through relative and absolute spellings — for a real
/// file (filesystem route) and an unresolvable path (lexical route).
#[test]
fn same_external_file_agrees_through_relative_and_absolute() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let base =
        std::env::temp_dir().join(format!("can-docs-r3b-ext-{}-{nanos}", std::process::id()));
    let proj = base.join("proj");
    let ext = base.join("ext");
    std::fs::create_dir_all(&proj).unwrap();
    std::fs::create_dir_all(&ext).unwrap();
    let _guard = TempfileGuard { dir: base.clone() };
    std::fs::write(ext.join("shop.can"), SHOP_SRC).unwrap();
    // Real file: `../ext/shop.can` from the project root vs absolute.
    let relative = "../ext/shop.can";
    let absolute = ext.join("shop.can").to_string_lossy().into_owned();
    assert!(std::path::Path::new(&absolute).is_absolute());
    let via_relative = portable_source_id(relative, &proj);
    let via_absolute = portable_source_id(&absolute, &proj);
    assert_eq!(via_relative, via_absolute, "identical identity");
    assert!(
        via_relative.starts_with("external:"),
        "identical external classification: {via_relative:?}"
    );
    assert!(via_relative.contains("shop.can"));
    // Unresolvable: nothing on disk at either spelling, same agreement.
    let missing_rel = "../ext-missing-4d2a/shop.can";
    let missing_abs = base
        .join("ext-missing-4d2a/shop.can")
        .to_string_lossy()
        .into_owned();
    assert!(!base.join("ext-missing-4d2a/shop.can").exists());
    let lex_rel = portable_source_id(missing_rel, &proj);
    let lex_abs = portable_source_id(&missing_abs, &proj);
    assert_eq!(lex_rel, lex_abs, "lexical agreement");
    assert!(
        lex_rel.starts_with("external:"),
        "lexical external classification: {lex_rel:?}"
    );
}

/// (R3b) Moved-checkout identity covers every spelling: two scratch
/// checkouts with the same relative layout normalize each spelling —
/// plain, `./`-prefixed, redundant and absolute — to the same identity.
#[test]
fn moved_checkout_identity_covers_every_spelling() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let base = std::env::temp_dir().join(format!("can-docs-r3b-mv-{}-{nanos}", std::process::id()));
    let dir_a = base.join("checkout-a");
    let dir_b = base.join("checkout-b");
    std::fs::create_dir_all(&dir_a).unwrap();
    std::fs::create_dir_all(&dir_b).unwrap();
    let _guard = TempfileGuard { dir: base };
    std::fs::write(dir_a.join("shop.can"), SHOP_SRC).unwrap();
    std::fs::write(dir_b.join("shop.can"), SHOP_SRC).unwrap();
    for spelling in ["shop.can", "./shop.can", "sub/../shop.can"] {
        let id_a = portable_source_id(spelling, &dir_a);
        let id_b = portable_source_id(spelling, &dir_b);
        assert_eq!(id_a, "shop.can", "checkout A: {spelling:?}");
        assert_eq!(id_b, "shop.can", "checkout B: {spelling:?}");
    }
    let abs_a = dir_a.join("shop.can").to_string_lossy().into_owned();
    let abs_b = dir_b.join("shop.can").to_string_lossy().into_owned();
    assert_ne!(abs_a, abs_b, "different absolute prefixes");
    assert_eq!(portable_source_id(&abs_a, &dir_a), "shop.can");
    assert_eq!(portable_source_id(&abs_b, &dir_b), "shop.can");
}

// --- Authored sequence examples (R-D07-04 remaining) ----------------------------

/// Sequence-form `examples`/`do` attached to a user scenario: a `let`
/// binding, an expected-error call, a plain call and an observation
/// assertion (established syntax from the `E5xxx` sequence suites).
const SEQUENCE_SRC: &str = concat!(
    "app Probe\n",
    "Given\n",
    " Expense { amount:int }\n",
    " policy Expense read=members\n",
    " fixture pending=Expense {amount=1}\n",
    "When\n",
    " scenario approve(expense:Expense) by=members\n",
    "  do\n",
    "   let x = 1\n",
    "  examples\n",
    "   do\n",
    "    let v = 1\n",
    "    call approve {expense=pending} by=self request={expense={version=v}} -> error(conflict)\n",
    "    call approve {expense=pending} by=self\n",
    "    expense.amount -> 1\n",
    "Then\n",
);

/// (R4b) The sequence fixture checks FULLY clean: every diagnostic family
/// is empty — parser/example-analysis admission alone is insufficient.
/// The block is scenario-owned with two calls (one expecting an error)
/// and observation assertions.
#[test]
fn sequence_fixture_checks_fully_clean() {
    let mut db = SourceDb::new();
    let id = db.add("probe.can".to_string(), SEQUENCE_SRC.to_string());
    let (program, diags) = check_program(&db, &[id], None);
    assert!(diags.is_empty(), "every family empty: {diags:?}");
    assert_eq!(program.examples.sequences.len(), 1);
    assert!(program.examples.tables.is_empty());
    let sequence = &program.examples.sequences[0];
    assert!(sequence.operation.is_some(), "scenario-owned sequence");
    assert_eq!(sequence.calls.len(), 2);
    assert!(
        sequence.calls.iter().any(|c| c.expects_error),
        "an expected-error call: {:?}",
        sequence.calls
    );
    assert_eq!(sequence.assertions, 2, "observation + expected-error");
}

/// (R4b) The scenario-owned sequence is preserved under its operation as
/// one authored `seq-1` entry: the COMPLETE source block verbatim (calls,
/// assertions, the `error(conflict)` spelling) with no invented single
/// expectation and no execution status. Declaration fixtures stay with
/// their declaration; table `row-N` labels are unchanged.
#[test]
fn operation_sequences_become_authored_source_examples() {
    let (json, model) = extract("probe.can", SEQUENCE_SRC);
    let approve = model.owners[0]
        .operations
        .iter()
        .find(|o| o.id == "Probe.approve")
        .expect("approve operation extracted");
    assert_eq!(approve.examples.len(), 1);
    let sequence = &approve.examples[0];
    assert_eq!(sequence.label, "seq-1");
    let want_block = "examples\n   do\n    let v = 1\n    call approve {expense=pending} by=self request={expense={version=v}} -> error(conflict)\n    call approve {expense=pending} by=self\n    expense.amount -> 1";
    assert_eq!(sequence.source, want_block, "complete block verbatim");
    assert_eq!(sequence.expected, None, "no invented single expectation");
    // The owning declaration keeps only its fixture: no sequence leak.
    let expense = &model.owners[0].declarations[0];
    assert_eq!(expense.name, "Expense");
    let labels: Vec<&str> = expense.examples.iter().map(|e| e.label.as_str()).collect();
    assert_eq!(labels, vec!["pending"]);
    // Authored expectations travel; execution status never does.
    assert!(json.contains("error(conflict)"), "authored spelling kept");
    for forbidden in ["passed", "\"failed\"", "executed", "execution"] {
        assert!(
            !json.contains(forbidden),
            "no {forbidden:?} in reference JSON"
        );
    }
    // JSON shape: `examples` on the op with label/source keys, `expected`
    // omitted (no single expectation), matching the existing row path.
    let value = json::parse(&json).expect("reference JSON parses");
    let owners = value.get("owners").and_then(Json::as_arr).unwrap();
    let ops = owners[0].get("operations").and_then(Json::as_arr).unwrap();
    assert_eq!(ops.len(), 1);
    let op_examples = ops[0].get("examples").and_then(Json::as_arr).unwrap();
    assert_eq!(op_examples.len(), 1);
    assert_eq!(
        op_examples[0].get("label").and_then(Json::as_str),
        Some("seq-1")
    );
    assert_eq!(
        op_examples[0].get("source").and_then(Json::as_str),
        Some(want_block)
    );
    assert!(
        op_examples[0].get("expected").is_none(),
        "no expected: omitted"
    );
    // Table labels are unchanged when sequences exist elsewhere.
    let (_table_json, table_model) = extract("probe.can", TABLE_SRC);
    let close = table_model.owners[0]
        .operations
        .iter()
        .find(|o| o.id == "Probe.close")
        .expect("close operation extracted");
    let row_labels: Vec<&str> = close.examples.iter().map(|e| e.label.as_str()).collect();
    assert_eq!(row_labels, vec!["row-1", "row-2"]);
}

// --- Mixed table + sequence order pin (R5) ----------------------------------------

/// One scenario carrying BOTH a sequence-form block (first in source) and
/// a table-form block (second): pins deterministic source-order merge.
/// A shape-grouped merge would emit `row-1` before `seq-1`; the contract
/// is `(file, span.start)` order with independent per-shape counters.
const MIXED_SRC: &str = concat!(
    "app Probe\n",
    "Given\n",
    " Expense { amount:int }\n",
    " policy Expense read=members\n",
    " fixture pending=Expense {amount=1}\n",
    "When\n",
    " scenario approve(expense:Expense) by=members\n",
    "  do\n",
    "   let x = 1\n",
    "  examples\n",
    "   do\n",
    "    call approve {expense=pending} by=self\n",
    "    expense.amount -> 1\n",
    "  examples expense=pending\n",
    "   as -> expense.amount\n",
    "   members -> 1\n",
    "Then\n",
);

/// (R5) Mixed table + sequence blocks on one operation merge in source
/// order: the earlier sequence block yields `seq-1` first, the later
/// table's data row yields `row-1` second. Per-shape counters (`seq-N`
/// counts sequence blocks, `row-N` counts data rows across tables) stay
/// independent while entries interleave by `(file, start)`.
#[test]
fn mixed_table_and_sequence_examples_merge_in_source_order() {
    let (db, id, program) = check_clean("probe.can", MIXED_SRC);
    assert_eq!(program.examples.tables.len(), 1);
    assert_eq!(program.examples.sequences.len(), 1);
    let model = extract_reference(&db, &[id], &program);
    let approve = model.owners[0]
        .operations
        .iter()
        .find(|o| o.id == "Probe.approve")
        .expect("approve operation extracted");
    let labels: Vec<&str> = approve.examples.iter().map(|e| e.label.as_str()).collect();
    assert_eq!(labels, vec!["seq-1", "row-1"]);
    let sequence = &approve.examples[0];
    assert_eq!(
        sequence.source,
        "examples\n   do\n    call approve {expense=pending} by=self\n    expense.amount -> 1"
    );
    assert_eq!(sequence.expected, None);
    let row = &approve.examples[1];
    assert_eq!(row.source, "members");
    assert_eq!(row.expected.as_deref(), Some("1"));
}

/// (R4 P-B) Dotted `#= shop.blurb` stays unresolved: the checker rejects it
/// (E2013 — no new syntax), so docs never renders dotted wording. Even
/// extracting past the failure carries no wording for the reference.
#[test]
fn dotted_message_references_stay_unresolved() {
    let mut db = SourceDb::new();
    let id = db.add("site.can".to_string(), DOTTED_REF_SRC.to_string());
    let (program, diags) = check_program(&db, &[id], None);
    assert!(
        diags.iter().any(|d| d.code == "E2013"),
        "checker rejects dotted refs: {diags:?}"
    );
    let model = extract_reference(&db, &[id], &program);
    for declaration in model.owners.iter().flat_map(|o| &o.declarations) {
        assert_eq!(
            declaration.description, None,
            "no dotted wording carried for {}",
            declaration.name
        );
    }
}

#[test]
fn missing_relative_roots_preserve_external_leading_parents() {
    let nanos = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("clock")
        .as_nanos();
    let missing = format!("can-docs-p09-missing-{}-{nanos}", std::process::id());
    for (prefix, expected) in [("..", "external:../../x"), ("../..", "external:../../../x")] {
        let root = std::path::Path::new(prefix).join(&missing);
        assert!(!root.exists(), "exercise the lexical fallback");
        // Qualifies parent preservation for public relative roots; the
        // separate absolute-external identity policy is unchanged.
        assert_eq!(portable_source_id("../../x", &root), expected);
    }
}
