import type { CatalogEntry, CatalogEnvelope, CatalogFeature } from "@canlang/contracts/values";

export const LANE02_CATALOG_VERSION = "0.1.0-lane02-draft";

/**
 * Single authored definition of every pure builtin signature (DESIGN §3) and
 * operator-lowering helper (DESIGN §13) owned by lane 02. Signatures are
 * transcribed from DESIGN; implementation lands per slice and flips
 * `availability`. JS names equal Can names verbatim for builtins (draft
 * witness: `local_date`, `add_days`); helpers use the §13 names. The two
 * `startsWith` draft hits are pre-uniformity drift, not a second convention.
 * Envelope shape implements the L1 IR-01 sketch; L1 acknowledgment pending.
 */
const BUILTINS: ReadonlyArray<CatalogEntry> = [
  { id: "count", js: "count", owner: "lane-02", kind: "builtin", signature: "count(domain:C<T>)->int", effects: "pure", availability: "implemented", notes: "Supplied-array evaluation here; record-query evaluation by lane-03." },
  { id: "flatten", js: "flatten", owner: "lane-02", kind: "builtin", signature: "flatten(domain:C<C<T>>)->T[]", effects: "pure", availability: "implemented" },
  { id: "sum", js: "sum", owner: "lane-02", kind: "builtin", signature: "sum(domain:C<int>)->int; sum(domain:C<decimal>)->decimal; sum(domain:C<duration>)->duration; sum(domain:C<money>,currency:currency)->money; sum(domain:nonempty C<money>)->money", effects: "pure", availability: "implemented", notes: "Supplied-array evaluation here; record-query evaluation by lane-03. Empty int/decimal/duration sums yield typed zero. Dispatcher sum(domain, element, currency?) routes by static element tag." },
  { id: "min", js: "min", owner: "lane-02", kind: "builtin", signature: "min(domain:C<O>)->O?; min(domain:nonempty C<O>)->O", effects: "pure", availability: "implemented", notes: "Supplied-array evaluation here; record-query evaluation by lane-03. Money min rejects inconsistent currencies." },
  { id: "max", js: "max", owner: "lane-02", kind: "builtin", signature: "max(domain:C<O>)->O?; max(domain:nonempty C<O>)->O", effects: "pure", availability: "implemented", notes: "Supplied-array evaluation here; record-query evaluation by lane-03. Money max rejects inconsistent currencies." },
  { id: "any", js: "any", owner: "lane-02", kind: "builtin", signature: "any(domain:C<T> as x,predicate:bool in x scope)->bool", effects: "pure", availability: "implemented", notes: "Alias-scoped predicate expression, not a callback. Empty domain is false. Pure core takes a plain predicate; generated code supplies the scope expression." },
  { id: "all", js: "all", owner: "lane-02", kind: "builtin", signature: "all(domain:C<T> as x,predicate:bool in x scope)->bool", effects: "pure", availability: "implemented", notes: "Alias-scoped predicate expression, not a callback. Empty domain is true. Pure core takes a plain predicate; generated code supplies the scope expression." },
  { id: "first", js: "first", owner: "lane-02", kind: "builtin", signature: "first(domain:ordered C<T>)->T?", effects: "pure", availability: "implemented", notes: "Requires stable ordering. Supplied-array evaluation here; record-query evaluation by lane-03." },
  { id: "group", js: "group", owner: "lane-02", kind: "builtin", signature: "group(domain:C<T> as x,key:K in x scope)->C<{key:K,items:T[]}>", effects: "pure", availability: "implemented", notes: "Typed equality incl. one null group; encounter order; only {key,items}. Pure core takes a plain key function; generated code supplies the scope expression." },
  { id: "at", js: "at", owner: "lane-02", kind: "builtin", signature: "at(array:T[],index:int)->T?", effects: "pure", availability: "implemented", notes: "Null for negative or out-of-range indices." },
  { id: "choose", js: "choose", owner: "lane-02", kind: "builtin", signature: "choose(condition:bool,yes:T,no:T)->T", effects: "pure", availability: "implemented", notes: "Strict pure selection; the condition must be a boolean and the winning input returns as-is. Any laziness is codegen's." },
  { id: "abs", js: "abs", owner: "lane-02", kind: "builtin", signature: "abs(value:int)->int; abs(value:decimal)->decimal; abs(value:duration)->duration; abs(value:money)->money", effects: "pure", availability: "implemented", notes: "Same overflow boundaries as negation. Dispatcher abs(value) routes by runtime kind (bigint covers int/duration; absDuration is behaviorally identical to absInt)." },
  { id: "round", js: "round", owner: "lane-02", kind: "builtin", signature: "round(value:int,scale:int)->decimal; round(value:decimal,scale:int)->decimal", effects: "pure", availability: "implemented", notes: "Scale 0-18, half-even; other scales fail." },
  { id: "lower", js: "lower", owner: "lane-02", kind: "builtin", signature: "lower(value:S)->text", effects: "pure", availability: "implemented", notes: "Full default Unicode case conversion. Result is text." },
  { id: "upper", js: "upper", owner: "lane-02", kind: "builtin", signature: "upper(value:S)->text", effects: "pure", availability: "implemented", notes: "Full default Unicode case conversion. Result is text." },
  { id: "trim", js: "trim", owner: "lane-02", kind: "builtin", signature: "trim(value:S)->text", effects: "pure", availability: "implemented", notes: "Removes pinned Unicode White_Space at both ends. Result is text." },
  { id: "contains", js: "contains", owner: "lane-02", kind: "builtin", signature: "contains(value:S,needle:text)->bool", effects: "pure", availability: "implemented", notes: "Exact case-sensitive scalar matching." },
  { id: "starts_with", js: "starts_with", owner: "lane-02", kind: "builtin", signature: "starts_with(value:S,prefix:text)->bool", effects: "pure", availability: "implemented", notes: "Exact case-sensitive scalar matching. Two camelCase draft hits are drift." },
  { id: "join", js: "join", owner: "lane-02", kind: "builtin", signature: "join(values:C<S>,separator:text)->text", effects: "pure", availability: "implemented", notes: "Domain order; empty domain yields empty text." },
  { id: "format", js: "format", owner: "lane-02", kind: "builtin", signature: "format(template:text,values:closed object of Display)->text; format(descriptor:message,locale:locale?)->text", effects: "pure", availability: "implemented", notes: "Display excludes decimal/money/datetime. Message overload requires explicit locale= (null selects app default). Plain overload is formatPlain; message overload is formatMessage." },
  { id: "app_url", js: "app_url", owner: "lane-02", kind: "builtin", signature: "app_url(path:text)->url", effects: "pure", availability: "implemented", notes: "Pure link construction against injected trusted origin; grants nothing. Pure core app_url(path, origin): generated code supplies the deployment origin; the Can surface takes path only." },
  { id: "active_member", js: "active_member", owner: "lane-03", kind: "builtin", signature: "active_member(person:user,team:Team)->bool", effects: "state-read", availability: "external", notes: "Needs membership state; signature authored here, implementation by lane-03." },
  { id: "overlaps", js: "overlaps", owner: "lane-02", kind: "builtin", signature: "overlaps(aStart:date,aEnd:date,bStart:date,bEnd:date)->bool; overlaps(aStart:datetime,aEnd:datetime,bStart:datetime,bEnd:datetime)->bool", effects: "pure", availability: "implemented", notes: "Nonempty half-open test; empty/reversed ranges return false." },
  { id: "local_date", js: "local_date", owner: "lane-02", kind: "builtin", signature: "local_date(value:datetime,zone:timezone)->date", effects: "pure", availability: "implemented", notes: "Civil date in pinned IANA zone; changes nothing." },
  { id: "local_instant", js: "local_instant", owner: "lane-02", kind: "builtin", signature: "local_instant(date:date,time:text,zone:timezone,fold:enum(earlier,later))->datetime", effects: "pure", availability: "implemented", notes: "Fold required when ambiguous; nonexistent local times fail. Time is HH:MM[:SS]." },
  { id: "add_days", js: "add_days", owner: "lane-02", kind: "builtin", signature: "add_days(value:date,days:int)->date", effects: "pure", availability: "implemented", notes: "Calendar days." },
  { id: "add_months", js: "add_months", owner: "lane-02", kind: "builtin", signature: "add_months(value:date,months:int)->date", effects: "pure", availability: "implemented", notes: "Original-anchor month-end clamping; overflow fails." },
  { id: "date_year", js: "date_year", owner: "lane-02", kind: "builtin", signature: "date_year(value:date)->int", effects: "pure", availability: "implemented", notes: "Gregorian year." },
  { id: "weekday", js: "weekday", owner: "lane-02", kind: "builtin", signature: "weekday(value:date)->int", effects: "pure", availability: "implemented", notes: "ISO Monday=1 through Sunday=7." },
  { id: "dates", js: "dates", owner: "lane-02", kind: "builtin", signature: "dates(from:date,until:date,limit:int)->date[]", effects: "pure", availability: "implemented", notes: "Ascending half-open [from,until). Limit is a work bound; excess fails." },
  { id: "money", js: "money", owner: "lane-02", kind: "builtin", signature: "money(value:int,currency:currency)->money; money(value:decimal,currency:currency)->money", effects: "pure", availability: "implemented", notes: "Checked constructor; rounds once to currency minor-unit scale, half-even." },
  { id: "date", js: "date", owner: "lane-02", kind: "builtin", signature: "date(value:text)->date", effects: "pure", availability: "implemented", notes: "Checked text constructor, YYYY-MM-DD." },
  { id: "datetime", js: "datetime", owner: "lane-02", kind: "builtin", signature: "datetime(value:text)->datetime", effects: "pure", availability: "implemented", notes: "Checked text constructor, RFC 3339 instant; nonzero sub-ms fractions rejected." },
  { id: "action", js: "action", owner: "lane-02", kind: "builtin", signature: "action(target:canonical user mutation,bindings:closed object of every record parameter)->singleton action(target)", effects: "pure", availability: "implemented", notes: "Packaging action(target, bindings) here (every binding carries its expected version); static target/canonicity validation by lane 1." },
  { id: "invocation", js: "invocation", owner: "lane-02", kind: "builtin", signature: "invocation(target:canonical local user mutation,arguments:complete owning input object)->singleton invocation(target)", effects: "pure", availability: "implemented", notes: "Packaging invocation(target, args) of decoded values here (nested versions preserved, never required); construction checking by L1, admission by L3." },
  { id: "random_secret", js: "random_secret", owner: "lane-03", kind: "builtin", signature: "random_secret()->secret", effects: "server-default-only", availability: "external", notes: "Server-defaults-only, stable per committed operation identity; not pure or client-callable." },
];

const HELPERS: ReadonlyArray<CatalogEntry> = [
  { id: "addMoney", js: "addMoney", owner: "lane-02", kind: "helper", signature: "addMoney(a:money,b:money)->money; same currency", effects: "pure", availability: "implemented" },
  { id: "subtractMoney", js: "subtractMoney", owner: "lane-02", kind: "helper", signature: "subtractMoney(a:money,b:money)->money; same currency", effects: "pure", availability: "implemented" },
  { id: "multiplyMoney", js: "multiplyMoney", owner: "lane-02", kind: "helper", signature: "multiplyMoney(m:money,f:int|decimal)->money", effects: "pure", availability: "implemented" },
  { id: "compareMoney", js: "compareMoney", owner: "lane-02", kind: "helper", signature: "compareMoney(a:money,b:money)->-1|0|1; same currency", effects: "pure", availability: "implemented" },
  { id: "equalMoney", js: "equalMoney", owner: "lane-02", kind: "helper", signature: "equalMoney(a:money,b:money)->bool; decidable across currencies (unequal)", effects: "pure", availability: "implemented" },
  { id: "negateMoney", js: "negateMoney", owner: "lane-02", kind: "helper", signature: "negateMoney(m:money)->money", effects: "pure", availability: "implemented" },
  { id: "divideDecimal", js: "divideDecimal", owner: "lane-02", kind: "helper", signature: "divideDecimal(a:int|decimal|money,b:int|decimal|money)->decimal; decimal rounding", effects: "pure", availability: "implemented" },
  { id: "durationBetween", js: "durationBetween", owner: "lane-02", kind: "helper", signature: "durationBetween(a:datetime,b:datetime)->duration", effects: "pure", availability: "implemented" },
  { id: "compareInstant", js: "compareInstant", owner: "lane-02", kind: "helper", signature: "compareInstant(a:datetime,b:datetime)->-1|0|1", effects: "pure", availability: "implemented" },
  { id: "compareDate", js: "compareDate", owner: "lane-02", kind: "helper", signature: "compareDate(a:date,b:date)->-1|0|1", effects: "pure", availability: "implemented" },
  { id: "compareDecimal", js: "compareDecimal", owner: "lane-02", kind: "helper", signature: "compareDecimal(a:decimal,b:decimal)->-1|0|1", effects: "pure", availability: "implemented" },
  { id: "addDuration", js: "addDuration", owner: "lane-02", kind: "helper", signature: "addDuration(d:duration,x:duration|datetime)->duration|datetime", effects: "pure", availability: "implemented" },
  { id: "subtractDuration", js: "subtractDuration", owner: "lane-02", kind: "helper", signature: "subtractDuration(d:duration|datetime,x:duration)->duration|datetime", effects: "pure", availability: "implemented" },
  { id: "same", js: "same", owner: "lane-02", kind: "helper", signature: "same(a:ref,b:ref)->bool; reference identity", effects: "pure", availability: "implemented" },
  { id: "equalValue", js: "equalValue", owner: "lane-02", kind: "helper", signature: "equalValue(c:context,canonicalTypeId:string,a:CanValue,b:CanValue)->bool; typed structural equality", effects: "pure", availability: "implemented", notes: "Leading c is the generated-code call form (DESIGN L992); shims drop it — the pure core is equalValue(typeId,a,b)." },
  { id: "int64", js: "int64", owner: "lane-02", kind: "helper", signature: "int64(v:bigint)->bigint; checked int64", effects: "pure", availability: "implemented" },
  { id: "addDecimal", js: "addDecimal", owner: "lane-02", kind: "helper", signature: "addDecimal(a:int|decimal,b:int|decimal)->decimal; exact, then 38-digit check", effects: "pure", availability: "implemented", notes: "Required by the decimal + matrix row; absent from the L992 draft list — L1 join to confirm." },
  { id: "subtractDecimal", js: "subtractDecimal", owner: "lane-02", kind: "helper", signature: "subtractDecimal(a:int|decimal,b:int|decimal)->decimal; exact, then 38-digit check", effects: "pure", availability: "implemented", notes: "Required by the decimal - matrix row; absent from the L992 draft list — L1 join to confirm." },
  { id: "multiplyDecimal", js: "multiplyDecimal", owner: "lane-02", kind: "helper", signature: "multiplyDecimal(a:int|decimal,b:int|decimal)->decimal; decimal rounding", effects: "pure", availability: "implemented", notes: "Required by the decimal * matrix row; absent from the L992 draft list — L1 join to confirm." },
  { id: "negateDecimal", js: "negateDecimal", owner: "lane-02", kind: "helper", signature: "negateDecimal(v:decimal)->decimal; exact, scale preserved", effects: "pure", availability: "implemented", notes: "Required by decimal unary minus; absent from the L992 draft list — L1 join to confirm." },
  { id: "divideMoney", js: "divideMoney", owner: "lane-02", kind: "helper", signature: "divideMoney(m:money,d:int|decimal)->money; round once half-even", effects: "pure", availability: "implemented", notes: "Required by the money/int|decimal / matrix row; absent from the L992 draft list — L1 join to confirm." },
  { id: "divideDurationByInt", js: "divideDurationByInt", owner: "lane-02", kind: "helper", signature: "divideDurationByInt(d:duration,n:int)->duration; exact ms or fail", effects: "pure", availability: "implemented", notes: "Required by the duration/int exact-division rule; absent from the L992 draft list — L1 join to confirm." },
  { id: "divideDurationMs", js: "divideDurationMs", owner: "lane-02", kind: "helper", signature: "divideDurationMs(a:duration,b:duration)->decimal; exact decimal division", effects: "pure", availability: "implemented", notes: "Required by the duration/duration / matrix row (no other lowering path expresses it); absent from the L992 draft list — L1 join to confirm." },
];

const FEATURES: ReadonlyArray<CatalogFeature> = [
  { name: "exact-int64", status: "implemented", description: "Checked signed 64-bit integer arithmetic and comparisons." },
  { name: "decimal-38-18-half-even", status: "implemented", description: "Exact decimal, <=38 significant digits, <=18 fractional, half-even boundaries." },
  { name: "money-pinned-scales", status: "implemented", description: "Money as minor units plus currency with pinned per-currency scales." },
  { name: "currency-iso-table", status: "implemented", description: "Pinned ISO 4217 admission table for currency values." },
  { name: "temporal-pure-helpers", status: "implemented", description: "Pure date/datetime/duration helpers with gap/fold/month-end rules." },
  { name: "timezone-pinned-intl", status: "implemented", description: "IANA zone resolution over pinned zone data via Intl." },
  { name: "unicode-scalar-text", status: "implemented", description: "Scalar-counted text ops with full default case conversion, no implicit normalization." },
  { name: "bounded-icu-profile", status: "implemented", description: "Bounded ICU MessageFormat validation and rendering." },
  { name: "locale-fallback-rfc4647", status: "implemented", description: "Whole-message RFC 4647 fallback with selected-locale plural rules." },
  { name: "pure-arrays", status: "implemented", description: "Pure array helpers over supplied values; record queries stay lane 3." },
  { name: "structural-equality", status: "implemented", description: "Typed structural equality plus reference identity." },
  { name: "schema-validation", status: "implemented", description: "Schema normalization and validation yielding structured violations." },
  { name: "wire-canonical-json", status: "implemented", description: "Exact canonical JSON/wire codecs per type id." },
  { name: "typed-errors", status: "implemented", description: "SchemaError/ValueError shapes distinct from business errors (DeliveryError owned by lane-04 services.ts)." },
  { name: "builtin-catalog", status: "draft", description: "This versioned single-authored signature catalog consumed by Rust and callers." },
];

export const CATALOG: CatalogEnvelope = {
  catalog_version: LANE02_CATALOG_VERSION,
  language_version: "1.0",
  entries: [...BUILTINS, ...HELPERS],
  features: FEATURES,
};
